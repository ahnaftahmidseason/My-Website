"use client";

import React from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { HeroVideo } from "@/components/HeroVideo";

export function HeroSection() {
  return (
    <section
      aria-labelledby="hero-heading"
      className="relative flex min-h-[100svh] w-full flex-col justify-end overflow-hidden bg-midnight pb-12 pt-32 sm:pb-16"
    >
      {/* Fullscreen Immediate Autoplay of User's Supplied Video */}
      <div className="absolute inset-0 z-0">
        <HeroVideo />
      </div>

      {/* Minimal, Confident Studio Typography & Bottom Bar */}
      <div className="editorial-container relative z-10">
        <div className="max-w-4xl">
          <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-silver">
            INDEPENDENT DIGITAL CREATOR
          </p>

          <h1
            id="hero-heading"
            className="mt-4 font-sans text-hero-monument font-semibold tracking-[-0.045em] text-glacial"
          >
            Ideas beyond
            <br />
            the ordinary.
          </h1>

          <p className="mt-5 max-w-lg font-sans text-base font-normal leading-relaxed text-silver sm:text-lg">
            Exploring AI, cinematic visuals, and the future of digital creativity.
          </p>
        </div>

        {/* Clean Bottom Bar: Actions Left, Official Channels Right */}
        <div className="mt-12 flex flex-col items-start justify-between gap-6 border-t border-white/10 pt-6 sm:flex-row sm:items-center">
          <div className="flex flex-wrap items-center gap-3">
            <Link
              href="/work"
              className="inline-flex min-h-[46px] items-center gap-2 rounded-full bg-glacial px-6 py-3 font-sans text-xs font-semibold uppercase tracking-[0.14em] text-midnight transition-opacity hover:opacity-90"
            >
              <span>Selected Work</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </Link>

            <a
              href="#motion-showreel"
              className="inline-flex min-h-[46px] items-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3 font-sans text-xs font-medium uppercase tracking-[0.14em] text-glacial backdrop-blur-md transition-colors hover:border-white/40 hover:bg-white/10"
            >
              <span>Watch Showreel</span>
            </a>
          </div>

          {/* Minimal Dual Channel Links */}
          <div className="flex items-center gap-3">
            <a
              href="https://www.youtube.com/@Ai_Spoiler"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 rounded-full border border-white/15 bg-midnight/60 py-1.5 pl-2 pr-3.5 backdrop-blur-md transition-colors hover:border-white/35"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/media/channels/ai-spoiler-logo.png"
                alt="AI Spoiler"
                className="h-6 w-6 rounded-full object-cover"
              />
              <span className="font-sans text-xs font-medium text-glacial">
                AI Spoiler
              </span>
            </a>

            <a
              href="https://www.youtube.com/@DarkReels9"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 rounded-full border border-white/15 bg-midnight/60 py-1.5 pl-2 pr-3.5 backdrop-blur-md transition-colors hover:border-white/35"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/media/channels/dark-reels-logo.png"
                alt="Dark Reels"
                className="h-6 w-6 rounded-full object-cover"
              />
              <span className="font-sans text-xs font-medium text-glacial">
                Dark Reels
              </span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
