"use client";

import React, { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { heroMediaManifest } from "@/data/media-manifest";

interface HeroVideoProps {
  videoSrc?: string;
}

export function HeroVideo({
  videoSrc = heroMediaManifest.mp4Src,
}: HeroVideoProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isMuted, setIsMuted] = useState(true);

  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    videoEl.muted = true;
    videoEl.defaultMuted = true;
    videoEl.playsInline = true;

    const startPlayback = () => {
      const playPromise = videoEl.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // Retry on first user interaction if browser blocks initial autoplay
        });
      }
    };

    startPlayback();
  }, [videoSrc]);

  const toggleMute = () => {
    const videoEl = videoRef.current;
    if (!videoEl) return;
    const nextMuted = !videoEl.muted;
    videoEl.muted = nextMuted;
    setIsMuted(nextMuted);
  };

  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-card border border-white/12 bg-[#02060D] shadow-[0_24px_80px_rgba(0,0,0,0.75)]">
      <video
        key={videoSrc}
        ref={videoRef}
        src={videoSrc}
        poster={heroMediaManifest.posterSrc}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        className="h-full w-full object-contain"
      />

      {/* Discreet Sound Toggle Button in Corner */}
      <button
        type="button"
        onClick={toggleMute}
        aria-label={isMuted ? "Unmute video" : "Mute video"}
        className="absolute right-4 bottom-4 z-20 inline-flex items-center gap-2 rounded-full border border-white/15 bg-midnight/80 px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-glacial backdrop-blur-md transition-colors hover:border-electric/60 hover:text-ice"
      >
        {isMuted ? (
          <>
            <VolumeX className="h-3.5 w-3.5 text-silver" aria-hidden="true" />
            <span>Sound Off</span>
          </>
        ) : (
          <>
            <Volume2 className="h-3.5 w-3.5 text-ice" aria-hidden="true" />
            <span>Sound On</span>
          </>
        )}
      </button>
    </div>
  );
}
